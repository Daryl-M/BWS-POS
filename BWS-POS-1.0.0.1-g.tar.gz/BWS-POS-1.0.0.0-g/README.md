BitcoinWSpectrum (BWS)

A pure POS chain with 57,000,000 million coin supply.
Max supply is capped at 90 million BWS.
6% stake reward
BWS chain has 2 minute block time. Minimum and maximum stake age is 6 hours & 30 days respectively
